from django.apps import AppConfig


class UnoConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'uno'
